import logging
import os
import time
import boto3
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Parameters
DYNAMODB_TABLE = "myProducts"

# Establish credentials
session_var = boto3.session.Session()
credentials = session_var.get_credentials()

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')

##############################################################################################
#Functions


# Main function (lambda handler)
def lambda_handler(event, context):
    os.environ['TZ'] = 'America/Los_Angeles'
    time.tzset()

    logger.debug('Received event: {}'.format(event))

    ##############################################################################################
    # Write items into DynamoDB

    # Verify that the table is empty
    scanResult = dynamodb.scan(TableName=DYNAMODB_TABLE)
    if scanResult['Count'] == 0:
        Items = []
        Items.append({'productFlavor':{'S':'cappuccino'},'productIngredients':{'L': [{'S':'coffee'},{'S':'milk'},{'S': 'cream'},{'S':'cacoa butter'},{'S':'vanilla seeds'},{'S':'sugar'},{'S':'glucose syrup'}]},'productId':{'N':'7'},'productType':{'S': 'ice cream'}})
        Items.append({'productFlavor':{'S':'strawberry'},'productIngredients':{'L':[{'S':'strawberry puree'},{'S':'milk'},{'S':'cream'},{'S':'fruit concentrate'},{'S':'proteins'}]},'productId':{'N':'8'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'cinnamon'},'productIngredients':{'L':[{'S':'cinnamon'},{'S':'milk'},{'S':'sugar'},{'S':'glucose syrup'},{'S':'gluten'}]},'productId':{'N':'10'},'productType':{'S':'frozen yogurt'}})
        Items.append({'productFlavor':{'S':'chocolate'},'productIngredients':{'L':[{'S':'chocolate'},{'S':'milk'},{'S':'sugar'},{'S':'citrus fibres'},{'S':'cocoa butter'},{'S':'sunflower oil'}]},'productId':{'N':'3'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'blueberry'},'productIngredients':{'L':[{'S':'blueberry'},{'S':'honey'},{'S':'salt'},{'S':'full fat yogurt'}]},'productId':{'N':'2'},'productType':{'S':'frozen yogurt'}})
        Items.append({'productFlavor':{'S':'pistachio'},'productIngredients':{'L':[{'S':'pistachio'},{'S':'pistachio pieces'},{'S':'milk'},{'S':'glucose syrup'},{'S':'coconut oil'},{'S':'citrus fibres'}]},'productId':{'N':'14'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'chocolate'},'productIngredients':{'L':[{'S':'chocolate powder'},{'S':'almond milk'},{'S':'vanilla extract'},{'S':'plain yogurt'},{'S':'gluten'}]},'productId':{'N':'1'},'productType':{'S':'frozen yogurt'}})
        Items.append({'productFlavor':{'S':'rum raisin'},'productIngredients':{'L':[{'S':'raisin'},{'S':'rum'},{'S':'sultana'},{'S':'milk'},{'S':'glucose syrup'},{'S':'citrus fibres'},{'S':'gluten'}]},'productId':{'N':'15'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'mint'},'productIngredients':{'L':[{'S':'mint flavouring'},{'S':'cocoa mass'},{'S':'milk'},{'S':'citrus fibres'},{'S':'fructose'}]},'productId':{'N':'9'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'orange'},'productIngredients':{'L':[{'S':'orange'},{'S':'full-fat yogurt'},{'S':'sugar'},{'S':'lemon juice'}]},'productId':{'N':'4'},'productType':{'S':'frozen yogurt'}})
        Items.append({'productFlavor':{'S':'stracciatella'},'productIngredients':{'L':[{'S':'chocolate'},{'S':'vanilla'},{'S':'milk'},{'S':'gluten'}]},'productId':{'N':'13'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'tiramisu'},'productIngredients':{'L':[{'S':'biscuit'},{'S':'coffee'},{'S':'mascarpone'},{'S':'milk'},{'S':'cream'},{'S':'cocoa powder'},{'S':'gluten'}]},'productId':{'N':'5'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'vanilla'},'productIngredients':{'L':[{'S':'vanilla'},{'S':'egg'},{'S':'whole milk'},{'S':'cream'}]},'productId':{'N':'6'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'banana'},'productIngredients':{'L':[{'S':'banana'},{'S':'milk'},{'S':'dextrose'},{'S':'lemon juice'},{'S':'yogurt'}]},'productId':{'N':'11'},'productType':{'S':'ice cream'}})
        Items.append({'productFlavor':{'S':'black cherry'},'productIngredients':{'L':[{'S':'cherry'},{'S':'honey'},{'S':'almond flavor'},{'S':'yogurt'}]},'productId':{'N':'12'},'productType':{'S':'frozen yogurt'}})
        Items.append({'productFlavor':{'S':'mango'},'productIngredients':{'L':[{'S':'mango'},{'S':'honey'},{'S':'agave nectar'},{'S':'yogurt'}]},'productId':{'N':'16'},'productType':{'S':'frozen yogurt'}})

        logger.debug('Items: {}'.format(Items))

        for Item in Items:
            logger.debug('Item: {}'.format(Item))
            dynamodb.put_item(TableName=DYNAMODB_TABLE,Item=Item)

        return "DynamoDB items added"
    else:
        return "Nothing added to the table, to prevent that existing content gets overwritten"
